USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

-- total amount of orders placed by each customer:

PRINT '1'
SELECT [c].[CustomerID], 
       SUM([LineTotal]) AS [SumAmount]
FROM [Sales].[SalesOrderDetail] AS [od]
     JOIN [Sales].[SalesOrderHeader] AS [oh] ON [od].[SalesOrderID] = [oh].[SalesOrderID]
     JOIN [Sales].[Customer] AS [c] ON [oh].[CustomerID] = [c].[CustomerID]
GROUP BY [c].[CustomerID];

PRINT '2'
SELECT [oh].[CustomerID], 
       SUM([od].[LineTotal]) AS [SumAmount]
FROM [Sales].[SalesOrderDetail] AS [od]
     JOIN [Sales].[SalesOrderHeader] AS [oh] ON [od].[SalesOrderID] = [oh].[SalesOrderID]
GROUP BY [oh].[CustomerID];

SET STATISTICS IO ON;

DROP INDEX IF EXISTS [IX_OrderDetail_OrderID_TotalLine] ON [Sales].[SalesOrderDetail];

CREATE INDEX [IX_OrderDetail_OrderID_TotalLine] ON [Sales].[SalesOrderDetail]([SalesOrderID]) INCLUDE([LineTotal]);

-- SOD reads: 1246
-- SOD reads: 467, -Compute Scalar



DROP INDEX IF EXISTS [IX_OrderHeader_SalesOrderID_CustomerID] ON [Sales].[SalesOrderHeader];

-- covering index:
CREATE INDEX [IX_OrderHeader_SalesOrderID_CustomerID] ON [Sales].[SalesOrderHeader]([SalesOrderID], [CustomerID]); --[SalesOrderID] = PK!

-- SOH reads: 689
-- SOH reads: 57