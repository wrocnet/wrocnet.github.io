USE [AdventureWorks2012];
GO
SET NOCOUNT ON;
GO

DROP INDEX IF EXISTS [IX_Person_ModifiedDate__FirstName_LastName] ON [Person].[Person];
CREATE NONCLUSTERED INDEX [IX_Person_ModifiedDate__FirstName_LastName]
ON [Person].[Person] ([ModifiedDate])
INCLUDE ([FirstName],[LastName])


PRINT '1'
SELECT p.[BusinessEntityID], p.[FirstName], p.[LastName]
FROM [Person].[Person] p
WHERE DATEADD(yy, 10 ,[p].[ModifiedDate]) >= GETDATE(); 


PRINT '2'
SELECT  p.[BusinessEntityID], p.[FirstName], p.[LastName]
FROM [Person].[Person] p
WHERE [p].[ModifiedDate] >= DATEADD(yy, -10 , GETDATE()); 


SET STATISTICS IO ON;
GO
--Execution plan OFF

-- sprawdzi� dla 8

