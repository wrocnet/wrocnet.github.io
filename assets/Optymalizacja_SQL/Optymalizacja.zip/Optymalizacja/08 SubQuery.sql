USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO 

-- login pracownika przy sprzeda�y
PRINT '1'
SELECT [poh].*, 
	  ( SELECT [e].[LoginID] FROM [HumanResources].[Employee] AS [e] WHERE [poh].[EmployeeID] = [e].[BusinessEntityID])
FROM [Purchasing].[PurchaseOrderHeader] AS [poh];


PRINT '2'
SELECT [poh].*, [e].[LoginID]
FROM [Purchasing].[PurchaseOrderHeader] AS [poh]
INNER JOIN [HumanResources].[Employee] AS [e] ON ([poh].[EmployeeID] = [e].[BusinessEntityID])
-- (left join)




-- dodajmy stanowisko pracownika
PRINT '1'
SELECT [poh].*, 
	  ( SELECT [e].[LoginID] FROM [HumanResources].[Employee] AS [e] WHERE [poh].[EmployeeID] = [e].[BusinessEntityID]),
	  ( SELECT [e].[JobTitle] FROM [HumanResources].[Employee] AS [e] WHERE [poh].[EmployeeID] = [e].[BusinessEntityID])
FROM [Purchasing].[PurchaseOrderHeader] AS [poh];


PRINT '2'
SELECT [poh].*, [e].[LoginID],[e].[JobTitle]
FROM [Purchasing].[PurchaseOrderHeader] AS [poh]
LEFT JOIN [HumanResources].[Employee] AS [e] ON ([poh].[EmployeeID] = [e].[BusinessEntityID])