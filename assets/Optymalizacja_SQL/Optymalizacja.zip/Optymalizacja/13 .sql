USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO

/*  existance */

SELECT column_list FROM table WHERE 0 < (SELECT count(*) FROM table2 WHERE ..)


Hide   Copy Code
SELECT column_list FROM table WHERE EXISTS (SELECT * FROM table2 WHERE ...)