USE [AdventureWorks2012];
GO

-- Proces wykonania
SELECT *
FROM [Person].[Person] AS p

SELECT TOP 100 *
FROM [Person].[Person] AS p



/*****/
-- czy to zapytanie jest wydajne?

SELECT p.LastName
FROM [Person].[Person] p
WHERE p.LastName LIKE 'Stan%';


-- a takie?

SELECT p.LastName
FROM [Person].[Person] p
WHERE p.LastName LIKE '%tan%';

-- i kolejne

SELECT p.*
FROM [Person].[Person] p
WHERE p.LastName LIKE '%tan%';