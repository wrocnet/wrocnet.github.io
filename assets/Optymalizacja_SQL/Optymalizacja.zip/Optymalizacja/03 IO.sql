USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

PRINT '1'
SELECT p.*
FROM [Person].[Person] p
WHERE p.LastName LIKE 'Tang'; 

PRINT '2'
SELECT p.*
FROM [Person].[Person] p WITH(INDEX (1))
WHERE p.LastName LIKE 'Tang'; 


SET STATISTICS TIME ON;
GO
SET STATISTICS IO ON;
GO
--Execution plan OFF