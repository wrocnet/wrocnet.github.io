USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO 


PRINT '1'
SELECT * 
FROM [Production].[Product] AS p
WHERE [p].[ProductID] IN (SELECT sod.[ProductID] FROM [Sales].[SalesOrderDetail] AS sod)

PRINT '2'
SELECT * 
FROM [Production].[Product] AS p
WHERE  EXISTS (SELECT * FROM [Sales].[SalesOrderDetail] AS sod WHERE sod.[ProductID] = p.[ProductID])


/*****************/
--[ProductID] -> null
BEGIN TRAN
ALTER TABLE [Sales].[SalesOrderDetail] ALTER COLUMN [ProductID] int NULL
GO
DISABLE TRIGGER [iduSalesOrderDetail] ON [Sales].[SalesOrderDetail]
INSERT INTO [Sales].[SalesOrderDetail]
(
    [SalesOrderID],
    --SalesOrderDetailID - this column value is auto-generated
    [CarrierTrackingNumber],
    [OrderQty],
    [ProductID],
    [SpecialOfferID],
    [UnitPrice],
    [UnitPriceDiscount],
    --LineTotal - this column value is auto-generated
    [rowguid],
    [ModifiedDate]
)
VALUES
(
    43659, -- SalesOrderID - int
    -- SalesOrderDetailID - int
    N'', -- CarrierTrackingNumber - nvarchar
    1, -- OrderQty - smallint
    NULL, -- ProductID - int
    0, -- SpecialOfferID - int
    0, -- UnitPrice - money
    0, -- UnitPriceDiscount - money
    -- LineTotal - numeric
    newid(), -- rowguid - uniqueidentifier
    '2016-12-10 18:27:10' -- ModifiedDate - datetime
)
/*********************/
PRINT '1'
SELECT * 
FROM [Production].[Product] AS p
WHERE [p].[ProductID] NOT IN (SELECT sod.[ProductID] FROM [Sales].[SalesOrderDetail] AS sod)

PRINT '2'
SELECT * 
FROM [Production].[Product] AS p
WHERE NOT EXISTS (SELECT * FROM [Sales].[SalesOrderDetail] AS sod WHERE sod.[ProductID] = p.[ProductID])

ROLLBACK


-- jak dzia�a not in z NULL?
SELECT * 
FROM [Production].[Product] AS p
WHERE [p].[ProductID] NOT IN (1, NULL)