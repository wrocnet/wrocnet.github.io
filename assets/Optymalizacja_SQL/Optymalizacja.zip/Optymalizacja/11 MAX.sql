USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO
-- ostatnie zam�wienie klienta
PRINT '1'

SELECT [soh].[CustomerID], [soh].[OrderDate], [soh].[SalesOrderID]
FROM [Sales].[SalesOrderHeader] AS [soh]
WHERE [soh].[OrderDate] =
(
    SELECT MAX([soh_inn].[OrderDate])
    FROM [Sales].[SalesOrderHeader] AS [soh_inn]
    WHERE [soh_inn].[CustomerID] = [soh].[CustomerID]
)
ORDER BY [soh].[CustomerID], [soh].[OrderDate];

PRINT '2'
-- co je�li mamy 2 zam�wienia z t� sam� dat�?


SELECT [soh].[CustomerID], [soh].[OrderDate], [soh].[SalesOrderID]
FROM [Sales].[SalesOrderHeader] AS [soh]
WHERE [soh].[OrderDate] =
(
    SELECT MAX([soh_inn].[OrderDate])
    FROM [Sales].[SalesOrderHeader] AS [soh_inn]
    WHERE [soh_inn].[CustomerID] = [soh].[CustomerID]
)
      AND [soh].[SalesOrderID] =
(
    SELECT MAX([soh_inn2].[SalesOrderID]) -- dodane najnowsze ID
    FROM [Sales].[SalesOrderHeader] AS [soh_inn2]
    WHERE [soh_inn2].[CustomerID] = [soh].[CustomerID]
          AND [soh_inn2].[OrderDate] = [soh].[OrderDate]
)
ORDER BY [soh].[CustomerID], [soh].[OrderDate];

PRINT '3'
-- funkcje okna

SELECT *
FROM
(
    SELECT DENSE_RANK() OVER(PARTITION BY [soh].[CustomerID] ORDER BY [soh].[OrderDate] DESC, [soh].[SalesOrderID] DESC) AS [Rank], [soh].[CustomerID], [soh].[OrderDate], [soh].[SalesOrderID]
    FROM [Sales].[SalesOrderHeader] AS [soh]
) AS [r]
WHERE [r].[Rank] = 1 -- <= 2
ORDER BY [r].[CustomerID], [r].[OrderDate];