USE [AdventureWorks2012];
GO
CREATE FULLTEXT CATALOG [test] WITH ACCENT_SENSITIVITY = ON;
GO


CREATE FULLTEXT INDEX ON [Production].[ProductModel] KEY INDEX [PK_ProductModel_ProductModelID] ON ([test]) WITH (CHANGE_TRACKING AUTO);
GO
ALTER FULLTEXT INDEX ON [Production].[ProductModel] ADD([CatalogDescription]);
GO

ALTER FULLTEXT INDEX ON [Production].[ProductModel] ENABLE;
GO
ALTER FULLTEXT CATALOG [test] REBUILD;
GO


SET STATISTICS IO ON;
GO

PRINT '1'
SELECT *
FROM [Production].[ProductModel]
WHERE CAST([CatalogDescription] AS NVARCHAR(MAX)) LIKE '%lightweight%'
      OR CAST([CatalogDescription] AS NVARCHAR(MAX)) LIKE '%frame%';

PRINT '2'
SELECT *
FROM [Production].[ProductModel]
WHERE CONTAINS([CatalogDescription], '"lightweight" OR "frame"');


-- ca�e frazy
-- wildcard tylko na ko�cu :/