USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

PRINT '1'
SELECT 'today' AS  [when], 
       COUNT(*) AS [orders]
FROM [Sales].[SalesOrderHeader] AS [soh]
WHERE [soh].[OrderDate] = '2005-11-13'
UNION ALL
SELECT 'last week' AS [when], 
       COUNT(*) AS    [orders]
FROM [Sales].[SalesOrderHeader] AS [soh]
WHERE [soh].[OrderDate] BETWEEN DATEADD(Week, -1, '2005-11-13') AND '2005-11-13'
UNION ALL
SELECT 'last month' AS [when], 
       COUNT(*) AS     [orders]
FROM [Sales].[SalesOrderHeader] AS [soh]
WHERE [soh].[OrderDate] BETWEEN DATEADD(Month, -1, '2005-11-13') AND '2005-11-13';

SET STATISTICS IO ON;

DROP INDEX IF EXISTS [IX_SalesOrderHeader_OrderDate] ON [Sales].[SalesOrderHeader];

CREATE NONCLUSTERED INDEX [IX_SalesOrderHeader_OrderDate] ON [Sales].[SalesOrderHeader]([OrderDate]);

-- Scan count 3, reads: 2067
-- Scan count 3, reads: 7






PRINT '2'
SELECT COUNT(CASE WHEN [soh].[OrderDate] = '2005-11-13' THEN 1 END) AS 'today',
	  COUNT(CASE WHEN [soh].[OrderDate] BETWEEN DATEADD(Week, -1, '2005-11-13') AND '2005-11-13' THEN 1 END) AS 'last week',
	  COUNT(CASE WHEN [soh].[OrderDate] BETWEEN DATEADD(Month, -1, '2005-11-13') AND '2005-11-13' THEN 1 END) AS 'last month'
FROM [Sales].[SalesOrderHeader] AS [soh]

-- Scan count 1, logical reads 73


PRINT '3'
WHERE [soh].[OrderDate] BETWEEN DATEADD(Month, -1, '2005-11-13') AND '2005-11-13'

-- Scan count 1, logical reads 3