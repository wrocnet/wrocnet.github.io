USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO 

PRINT '1'
SELECT [a].[City], 
       [sp].[Name], 
       COUNT(*)
FROM [Person].[Address] AS [a]
     JOIN [Person].[StateProvince] AS [sp] ON [sp].[StateProvinceID] = [a].[StateProvinceID]
WHERE [sp].[Name] = 'Washington'
GROUP BY [a].[City], 
         [sp].[Name]
UNION ALL
SELECT NULL, 
       [sp].[Name], 
       COUNT(*)
FROM [Person].[Address] AS [a]
     JOIN [Person].[StateProvince] AS [sp] ON [sp].[StateProvinceID] = [a].[StateProvinceID]
WHERE [sp].[Name] = 'Washington'
GROUP BY [sp].[Name]
UNION ALL
SELECT NULL, 
       NULL, 
       COUNT(*)
FROM [Person].[Address] AS [a]
     JOIN [Person].[StateProvince] AS [sp] ON [sp].[StateProvinceID] = [a].[StateProvinceID]
WHERE [sp].[Name] = 'Washington'
GROUP BY [sp].[Name];


--Table 'Address'. Scan count 3, logical reads 5466
--Table 'StateProvince'. Scan count 0, logical reads 6

PRINT '2'
SELECT [a].[City], 
       [sp].[Name], 
       COUNT(*)
FROM [Person].[Address] AS [a]
     JOIN [Person].[StateProvince] AS [sp] ON [sp].[StateProvinceID] = [a].[StateProvinceID]
WHERE [sp].[Name] = 'Washington'
GROUP BY ROLLUP([sp].[Name], [a].[City]);


--Table 'Address'. Scan count 1, logical reads 216
--Table 'StateProvince'. Scan count 0, logical reads 2