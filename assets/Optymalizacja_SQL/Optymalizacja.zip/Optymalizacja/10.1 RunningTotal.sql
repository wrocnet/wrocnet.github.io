USE RunningTotals;
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO

PRINT '1'
SELECT [st1].[Date], 
       [st1].[TicketCount], 
       [RunningTotal] = SUM([st2].[TicketCount])
FROM [dbo].[SpeedingTickets] AS [st1]
     INNER JOIN [dbo].[SpeedingTickets] AS [st2] ON [st2].[Date] <= [st1].[Date]
GROUP BY [st1].[Date], 
         [st1].[TicketCount]
ORDER BY [st1].[Date];

-- Subquery?

PRINT '2'
SELECT [Date], 
       [TicketCount], 
       [RunningTotal] = [TicketCount] + COALESCE(
                                                (
                                                    SELECT SUM([TicketCount])
                                                    FROM [dbo].[SpeedingTickets] AS [s]
                                                    WHERE [s].[Date] < [o].[Date]
                                                ), 0)
FROM [dbo].[SpeedingTickets] AS [o]
ORDER BY [Date];
-- look at Scan and reads :/


-- Recursive CTE?

-- Assumption: key column has no gaps!!!
PRINT '3'
;WITH x
     AS (
     SELECT [Date], 
            [TicketCount], 
            [RunningTotal] = [TicketCount]
     FROM [dbo].[SpeedingTickets]
     WHERE [Date] = '19840101'
     UNION ALL
     SELECT [y].[Date], 
            [y].[TicketCount], 
            [x].[RunningTotal] + [y].[TicketCount]
     FROM [x]
          INNER JOIN [dbo].[SpeedingTickets] AS [y] ON [y].[Date] = DATEADD(DAY, 1, [x].[Date]))
     SELECT [Date], 
            [TicketCount], 
            [RunningTotal]
     FROM [x]
     ORDER BY [Date]
     OPTION(MAXRECURSION 10000);



-- Window functions 
PRINT '4'
SELECT
	[Date],
	TicketCount,
	SUM(TicketCount) OVER (ORDER BY [Date] ROWS UNBOUNDED PRECEDING)
FROM dbo.SpeedingTickets
ORDER BY [Date];