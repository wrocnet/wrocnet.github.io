USE [AdventureWorks2012];
GO

SET NOCOUNT ON;
GO

SET STATISTICS IO ON;
GO

PRINT '1'
SELECT *
FROM [Sales].[SalesOrderHeader] AS [h]
     INNER JOIN [Sales].[SalesOrderDetail] AS [d] ON [h].[SalesOrderID] = [d].[SalesOrderID]
WHERE [h].[TotalDue] > 100
      AND ([d].[OrderQty] > 5
           OR [d].[LineTotal] < 1000.00);

PRINT '2'
SELECT *
FROM [Sales].[SalesOrderHeader] AS [h]
     INNER JOIN [Sales].[SalesOrderDetail] AS [d] WITH (FORCESEEK) ON [h].[SalesOrderID] = [d].[SalesOrderID]
WHERE [h].[TotalDue] > 100
      AND ([d].[OrderQty] > 5
           OR [d].[LineTotal] < 1000.00);
GO


/*

WITH  ( <table_hint> [ [, ]...n ] )

<table_hint> ::= 
[ NOEXPAND ] { 
    INDEX ( index_value [ ,...n ] ) | INDEX =  ( index_value )
  | FASTFIRSTROW 
  | FORCESEEK [( index_value ( index_column_name  [ ,... ] ) ) ]
  | FORCESCAN
  | HOLDLOCK 
  | NOLOCK 
  | NOWAIT
  | PAGLOCK 
  | READCOMMITTED 
  | READCOMMITTEDLOCK 
  | READPAST 
  | READUNCOMMITTED 
  | REPEATABLEREAD 
  | ROWLOCK 
  | SERIALIZABLE 
  | TABLOCK 
  | TABLOCKX 
  | UPDLOCK 
  | XLOCK 
} 

*/